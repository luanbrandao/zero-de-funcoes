export class BisseccaoModel {
    interacao : number;
    a : number ;
    b : number ;
    c : number ;
    fC : number ;
  }
  
export class Bisseccoes {
    bissecoes: Array<BisseccaoModel>
  }
  